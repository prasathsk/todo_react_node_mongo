import React, { useState } from "react";
import { Button, Form } from 'react-bootstrap';

function ButtonCount() {
    const [showButton, setShowButton] = useState(false);
    const [buttonDisable, setButtonDisable] = useState(true);
    const [count, setCount] = useState(0);
    const [samText, setSamText] = useState('');
    const [val, setVal] = useState([]);

    const switchButton = (e) => {
        // setCheckBox(e.target.checked === true ? true : false);
        setCount((e.target.checked === true) ? (count + 1) : (count - 1));
    };

    const userName = (e) => {
        // setSamText
        if (e.target.value !== '') {
            setSamText(e.target.value);
            setButtonDisable(false);
        }
        else {
            setSamText('');
            setButtonDisable(true);
        }
    };

    const dynamicButton = () => {
        setVal([...val, []]);
        setShowButton(true);
    };

    // const buttonCircle = {
    //     .btn-circle.btn-sm { 
    //         width: 30px; 
    //         height: 30px; 
    //         padding: 6px 0px; 
    //         border-radius: 15px; 
    //         font-size: 8px; 
    //         text-align: center; 
    //     } 
    //     .btn-circle.btn-md { 
    //         width: 50px; 
    //         height: 50px; 
    //         padding: 7px 10px; 
    //         border-radius: 25px; 
    //         font-size: 10px; 
    //         text-align: center; 
    //     } 
    //     .btn-circle.btn-xl { 
    //     width: '70px', 
    //     height: '70px', 
    //     padding: '10px 16px',
    //     // borderR
    //     border-radius: '35px', 
    //     font-size: '12px',
    //     text-align: 'center' 
    //     } 
    // };

    return (
        <div className="align-middle m-auto">
            <input type='text' placeholder='name' value={samText} onChange={(e) => userName(e)} />
            <Button onClick={dynamicButton} className="ml-3" disabled={buttonDisable}>Submit</Button>
            <p className="mt-4">Show the switch on/off count:{count}</p>
            {showButton === true ? val.map((data, index) => {
                return (
                    <div key={index} className="d-flex justify-content-center">
                        {/* <Button style={buttonCircle}>submit</Button> */}
                        <Form>
                            <Form.Check type="switch" id="dButton" label='dynamic button'
                                onChange={(e) => switchButton(e)}
                                defaultChecked={false}></Form.Check>
                        </Form>
                    </div>
                );
            }) : ""}
        </div>
    );
};

export default ButtonCount;